================================
SRWLucene 1.0
================================

Addon for SRW/U 2.0 from OCLC.  This extension adds native lucene support to SRW.

For details instructions see:

   SRW Homepage   - http://www.oclc.org/research/software/srw/default.htm
   SRWLucene wiki - http://wiki.osuosl.org/display/OCKPub/SRWLucene

